Dependencies
============

[select2](http://ivaynberg.github.com/select2/)

Usage
====

See the [Select2Cell](http://wyuenho.github.com/backgrid/#api-select2-cell) section in
the documentation.
