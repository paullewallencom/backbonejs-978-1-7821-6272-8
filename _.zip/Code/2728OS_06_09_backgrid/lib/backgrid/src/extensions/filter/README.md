Dependencies
============

[bootstrap](http://twitter.github.com/bootstrap/) (optional)
[lunr](http://lunrjs.com) (LunrFilter)

Usage
====

See the [Filter](http://wyuenho.github.com/backgrid/#api-filter) section in
the documentation.
