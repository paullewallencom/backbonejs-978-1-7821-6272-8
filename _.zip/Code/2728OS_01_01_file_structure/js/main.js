(function($){

  // Object declarations goes here

  $(document).ready(function () {

    // Start application code goes here

  });
})(jQuery);