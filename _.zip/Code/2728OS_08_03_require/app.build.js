({
    appDir: "./src",
    baseUrl: "js",
    dir: "build",
    mainConfigFile: "src/js/app.js",
    modules: [
        {
            name: "app"
        },
    ]
})

